#pragma once
#include <iostream>
#include <locale>

#include <string>
#include <cstring>
#include <fstream>

namespace lab4 
{
	using namespace std;

	namespace task1 
	{
		bool run(void);
	}

	namespace task2 
	{
		bool run(void);
	}

	namespace task3 
	{
		bool run(void);
	}

	void lab(void);
}